package fa222rw_assign4.Time;

public class A80 {public static void main(String[] args) {
	String a = "a";
	for (int i = 0; i < 79; i++) {
		a += "a";
	}
	System.out.print(a);
}
}
