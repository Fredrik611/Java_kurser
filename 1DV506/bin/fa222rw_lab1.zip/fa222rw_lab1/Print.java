/**
 * printar ut "Kunskap �r makt" p� olika s�tt.
 * @author Fredrik
 * LAB1 - uppgift 5
 */

package fa222rw_lab1;

public class Print {
	public static void main(String[] args ) {
		System.out.println("Kunskap �r makt");
		System.out.println("Kuskap \n�r \nmakt");
		System.out.println("================");
		System.out.println("|Kunskap �r makt|");
		System.out.println("================");
	}
}
