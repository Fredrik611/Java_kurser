/**
 * 
 */
package fa222rw_lab1;

/** First program prints out "Hello World"
 * @author Fredrik
 * LAB1 - uppgift 4
 */
public class Hello {

	/**
	 * @param args 
	 */
	public static void main(String[] args) {
		System.out.println("Hello World");
	}

}
